package com.dolinsek.elias.cashcockpit;

import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import 	android.support.v4.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.dolinsek.elias.cashcockpit.components.Database;

import org.json.JSONException;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    /**
     * BottomNavigationView for navigating
     */
    private BottomNavigationView mBottomNavigationView;

    private CockpitFragment cockpitFragment = new CockpitFragment();
    private HistoryFragment historyFragment = new HistoryFragment();
    private StatisticsFragment statisticsFragment = new StatisticsFragment();
    private DatabaseFragment databaseFragment = new DatabaseFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState == null){
            //Show CockpitFragment
            replaceFragment(cockpitFragment);
        }

        mBottomNavigationView = (BottomNavigationView) findViewById(R.id.bnv_main);
        mBottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                //Switch between fragments
                switch (item.getItemId()){
                    case R.id.navigation_database:
                        replaceFragment(databaseFragment);
                            return true;
                    case R.id.navigation_cockpit:
                        replaceFragment(cockpitFragment);
                            return true;
                    case R.id.navigation_history:
                        replaceFragment(historyFragment);
                            return true;
                    case R.id.navigation_statistics:
                        replaceFragment(statisticsFragment);
                            return true;
                    case R.id.navigation_settings:
                        return false;
                }

                return false;
            }
        });

    }

    /**
     * Replaces current Fragment with new Fragment
     * @param fragment new Fragment
     */
    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.replace(R.id.ll_main, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.options_activity_main, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_settings){

            //Start SettingsActivity
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
